//
//  QCloudLogicInjection.h
//  Pods
//
//  Created by stonedong on 16/7/30.
//
//

#ifndef QCloudLogicInjection_h
#define QCloudLogicInjection_h
#import "QCloudExtendClass.h"
#endif /* QCloudLogicInjection_h */
