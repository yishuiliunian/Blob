//
//  QCloudJSONHttpRequest.h
//  Pods
//
//  Created by Dong Zhao on 2017/3/13.
//
//

#import "QCloudBizHTTPRequest.h"

@interface QCloudJSONHttpRequest : QCloudBizHTTPRequest

@end
