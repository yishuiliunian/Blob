//
//  QCloudHTTPFileRequest.h
//  Pods
//
//  Created by Dong Zhao on 2017/3/2.
//
//

#import "QCloudHTTPRequest.h"

@interface QCloudHTTPFileRequest : QCloudHTTPRequest

@end
