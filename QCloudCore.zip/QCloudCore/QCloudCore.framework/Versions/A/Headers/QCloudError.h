//
//  QCloudError.h
//  Pods
//
//  Created by Dong Zhao on 2017/3/31.
//
//

#import <Foundation/Foundation.h>
FOUNDATION_EXTERN NSString* const QCloudErrorDomain;
