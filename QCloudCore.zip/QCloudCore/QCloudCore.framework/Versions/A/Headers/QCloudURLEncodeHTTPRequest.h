//
//  QCloudURLEncodeHTTPRequest.h
//  Pods
//
//  Created by Dong Zhao on 2017/4/11.
//
//

#import <QCloudCore/QCloudCore.h>

@interface QCloudURLEncodeHTTPRequest : QCloudBizHTTPRequest

@end
