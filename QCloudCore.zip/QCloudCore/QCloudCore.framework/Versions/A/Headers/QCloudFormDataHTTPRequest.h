//
//  QCloudFormDataHTTPRequest.h
//  Pods
//
//  Created by Dong Zhao on 2017/3/13.
//
//

#import "QCloudBizHTTPRequest.h"

@interface QCloudFormDataHTTPRequest : QCloudBizHTTPRequest

@end
