//
//  QCloudIntelligenceTimeOutAdapter.h
//  BaiduWallet_CommonLogic
//
//  Created by tencent on 5/23/16.
//  Copyright © 2016 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QCloudIntelligenceTimeOutAdapter : NSObject
+ (double) recommendTimeOut;
@end
