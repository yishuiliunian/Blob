
#import <Foundation/Foundation.h>

#ifndef QCloudCoreModuleVersion_h
#define QCloudCoreModuleVersion_h
#define QCloudCoreModuleVersionNumber 1000
FOUNDATION_EXTERN NSString * const QCloudCoreModuleVersion;
FOUNDATION_EXTERN NSString * const QCloudCoreModuleName;


#endif
        
