//
//  QCloudHTTPRequest_SessionPrivate.h
//  BaiduWallet_CommonLogic
//
//  Created by tencent on 5/12/16.
//  Copyright © 2016 Baidu. All rights reserved.
//

#import "QCloudHTTPRequest.h"

@interface QCloudHTTPRequest ()
@end
